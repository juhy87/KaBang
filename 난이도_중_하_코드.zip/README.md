# KaBang
1. 난이도 : 중/하
- 실행 : java -jar KakaoBank.jar {input file} {template file}
- example : java -jar KakaoBank.jar input.txt template.txt
- file 위치 : command 명령어 하는 위치
- result : output.txt
