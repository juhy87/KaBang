package enums;

public enum TemplateType {
    NORMAL,
    FOR,
    END;
}
